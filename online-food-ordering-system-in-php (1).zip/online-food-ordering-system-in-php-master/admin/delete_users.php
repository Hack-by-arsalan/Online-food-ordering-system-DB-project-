<?php
include("../connection/connect.php");
error_reporting(0);
session_start();
//transaction
mysqli_query($db, "START TRANSACTION");

// sending query
mysqli_query($db,"DELETE FROM users WHERE u_id = '".$_GET['user_del']."'");
if($query)
{
    mysqli_query($db, "COMMIT");
}
else
{
    mysqli_query($db, "ROLLBACK");
}
header("location:allusers.php");  

?>
