<?php
include("../connection/connect.php");
error_reporting(0);
session_start();
//transaction
mysqli_query($db, "START TRANSACTION");
// sending query
$query=mysqli_query($db,"DELETE FROM dishes WHERE d_id = '".$_GET['menu_del']."'");
if($query)
{
    mysqli_query($db, "COMMIT");
}
else
{
    mysqli_query($db, "ROLLBACK");
}
header("location:all_menu.php");  

?>
