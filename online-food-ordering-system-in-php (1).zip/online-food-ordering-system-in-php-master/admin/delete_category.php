<?php
include("../connection/connect.php");
error_reporting(0);
session_start();
mysqli_query($db, "START TRANSACTION");


// sending query
$query=mysqli_query($db,"DELETE FROM res_category WHERE c_id = '".$_GET['cat_del']."'");
//transactions
if($query)
{
    mysqli_query($db, "COMMIT");
}
else
{
    mysqli_query($db, "ROLLBACK");
}
header("location:add_category.php");  

?>
