<?php
include("connection/connect.php"); 
error_reporting(0);
session_start();
mysqli_query($db, "START TRANSACTION");



$query = mysqli_query($db,"DELETE FROM users_orders WHERE o_id = '".$_GET['order_del']."'"); 
if($query)
{
    mysqli_query($db, "COMMIT");
}
else
{
    mysqli_query($db, "ROLLBACK");
}
header("location:your_orders.php");  

?>
